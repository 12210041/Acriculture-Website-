<!-- <script>
    alert("h");
</script> -->
<?php
include '../includes/dbConnection.php';
if(isset($_POST['dist_id']))
{   $id=$_POST['dist_id'];
    echo "
        <option value=select>-select-</option>
        ";
    $sql="select * from block where dist_id=$id;";
    $res=mysqli_query($conn,$sql);
    while($data=mysqli_fetch_assoc($res))
    {
        echo "
        <option value=$data[block_id]>$data[block_name]</option>
        ";
}
   
}else if(isset($_POST['block_id']))
{   $id=$_POST['block_id'];
    echo "
        <option value=select>-select-</option>
        ";
    $sql="select * from panchayat where block_id=$id;";
    $res=mysqli_query($conn,$sql);
    while($data=mysqli_fetch_assoc($res))
    {
        echo "
        <option value='$data[p_id]'>$data[panchayat]</option>
        ";
}  
}

?>