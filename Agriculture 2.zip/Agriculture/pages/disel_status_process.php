<style>
    .dow{
        padding:10px;
        background:green;
        border-radius:10px;
        color:white;
        justify-content:center;
        float:right;
    }
    .dow:hover{
        background:lightgreen;
        color:black;
        cursor:pointer;
    }
    
    </style>

<?php
include '../includes/dbConnection.php';
if(isset($_GET['reg']))
{
$sql="select * from diesel where concat(farmer_reg,d_id)='$_GET[reg]'";
$res=mysqli_query($conn,$sql);
$row=mysqli_fetch_assoc($res);
if(mysqli_num_rows($res)>0)
{
    $regi=$row['farmer_reg'].$row['d_id'];
echo "
<table width=100% border=1>
<tr style=border:none>
<th style=border:none><img src='../image/up-logo@@@.png' width=100px height=100px></th>
<td style=color:red;border:none></td>
<th style=border:none></th>
<td style=border:none><img src='https://png.pngtree.com/png-clipart/20210808/original/pngtree-jai-jawan-kisan-t-shirt-design-hindi-local-lettering-with-texture-png-image_6615811.jpg' width=100px height=100px></td>
</tr>
<tr>
<th >Application Number</th>
<td style=color:red>: $regi</td>
<th>Application Status</th>
<td>: $row[status]</td>
</tr>
<th >Apply Date & Time</th>
<td style=color:red>: $row[applydate]</td>
<th >Reason</th>
<td style=color:red>: $row[reason]</td>
</tr>

</table>
";
}
else
{
    echo "<p style='color:red;font-size:30px;text-align:center;'>Record Not Availabe or Invalid Registration Number</p>";
}
}

?>