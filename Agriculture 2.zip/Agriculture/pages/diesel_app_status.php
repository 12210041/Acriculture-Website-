<?php
include 'navbar.html';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <script src="../JS/jquery.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Apply For diesel</title>
    <style>
        .main{
            position:sticky;
            width:70%;
            left:15%;
            top:30%;
            border:1px solid black;
        }
        .head{
            background-color:rgb(187,105,41);
            height:100px;
        }
        .search{
            display:grid;
            background-color:rgb(233,163,38);
            grid-template-columns:20% 80%;
            color:red;
            padding:auto;
            font-size:20px;
            font-weight:600;
            width:100%;
        }
        table td,th{
            padding:5px;
            border:1px solid green;
        }
        @media print { 
            .main { 
              width:100%;
              left:0;
            } 
            nav{
                display:none;
            }
            .nn{
                display:none;
            }
            #print{
                display:none;
            }
            .ser{
                display:none;
            }
        } 
        </style>
</head>
<body>
    <section class="main">
        <div class="head">
        <a href="#" style="font-size:30px;float:right;color:black;padding:20px;" id="print"><i class="fa-solid fa-print" onclick="window.print();"></i></a>
        </div>
        <div class="search">
            <div style="    ">
                <p>Application Status for Diesel Anudan Yojna</p>
        </div>
            <div >
            <table style="float:right">
                    <tr class="ser">
                        <td >
                            <select name="choose">
                         
                                <option value="1">Application Number</option>
                               
                            </select>
                        </td>
                        <td>
                            <form action="" method="GET" onsubmit="return false">
                                <input type="search" name="s" id="s">
                                <button  name="search" id="search" style="background:lightblue;width:30px"><i class="fa fa-magnifying-glass"></i></button>
                            </form>
                        </td>
                     </tr>
                </table>
            </div>
        </div>
        <div id="fetch">
     
           
            
          
        </div>

</section>
<script>
    $(document).ready(function(){
        $('#search').click(function(){
            let reg=$('#s').val();
            $.ajax({
                type:'GET',
                url:'disel_status_process.php',
                data:'reg='+reg,
                success:function(data)
                {
                    $('#fetch').html(data);
          
                }
            });
        });
        
    });
   
    </script>
</body>
</html>