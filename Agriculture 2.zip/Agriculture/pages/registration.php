<?php
include '../includes/dbConnection.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="../css/style.css">
  <link rel="stylesheet" href="../css/reg.css">
  <script src="../JS/jquery.js"></script>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
  <title>farmer registration</title>
  <style>
    .label::after{
    content: '*';
    color: red;
}
div input:focus{
    box-shadow: 2px 2px 4px green;
    background-color: rgb(206, 237, 239);
}
select{
    width:100%;
}
.succ{
    width:30%;
    height:30vh;
    background-color:white;
    display:none;

}
.succ img{
    width:30%;
    align:center;
    margin-left:150px;
  filter: contrast(5);

}
    </style>
</head>

<body >

<section class="middle">
  <?php include 'navbar.html';?>
</section>
<section class="container  frm">
    <div style="color:red;text-align:center;font-size:30px;display:none;" id="fail">Something went wrong. Please try agin</div>
    <form method="POST" enctype="multipart/form-data" action="registration_process.php" onsubmit="return formValidation()">
    <fieldset>
        <legend align="center" style="background-color:rgb(93, 110, 198);color:aliceblue">किसान संबंधित जानकारी दर्ज करें !</legend>
        <div class="row">
            <div class="col-lg-2 col-md-2 col-sm-3 col-2  m-buttom">
                <p >Year</p>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-3 col-2  m-buttom">
               <p id="year" value="2023-24" name="year">2023-24</p>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-3 col-3  m-buttom">
                <p class="label">Farmer Type</p>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-3 col-4 m-buttom">
               <select name="farmer_type" id="ftype">
               <option value="select">-select-</option>
                <option value="रैयत किसान">रैयत किसान</option>
                 <option value="गैर रैयत">गैर रैयत</option>
               </select>
            </div>
            <div class="col-lg-2   m-buttom">
                <p class="label">First Name</p>
            </div>
            <div class="col-lg-2 m-buttom">
               <input type="text" id="fname" name="fname" class="" placeholder="First Name">
            </div>
            <div class="col-lg-2   m-buttom">
                <p >Last Name</p>
            </div>
            <div class="col-lg-2 m-buttom">
               <input type="text" id="lname" name="lname" class="" placeholder="Last Name">
            </div>
            <div class="col-lg-2   m-buttom">
                <p class="label">W/O,S/O</p>
            </div>
            <div class="col-lg-2 m-buttom">
               <input type="text" id="gaurdiun" name="gaurdiun" class="" placeholder="">
            </div>
            <div class="col-lg-2   m-buttom">
                <p class="label">DOB</p>
            </div>
            <div class="col-lg-2 m-buttom">
               <input type="date" id="dob" class="" name="dob">
            </div>
             <div class="col-lg-2   m-buttom">
                <p >Present Age</p>
            </div>
            <div class="col-lg-2">
               <input type="text" id="age" name="age" class="" disabled>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-3 col-2 m-buttom">
                <p class="label">Gender</p>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-3 col-4 m-buttom">
               <select  name="sex" id="sex">
                <option value="select">-select-</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="Other">Other</option>
               </select>
            </div>
             <div class="col-lg-2 col-md-2 col-sm-3 col-3 m-buttom">
                <p class="label">Category</p>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-3 col-3 m-buttom">
               <select name="category" id="category">
                <option value="select">-select-</option>
                <option value="General">General</option>
                <option value="OBC">OBC</option>
                <option value="SC">SC</option>
                <option value="ST">ST</option>
               </select>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-3 col-2 m-buttom">
                <p class="label">Farmer range</p>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-3 col-4 m-buttom">
               <select name="farmerRange" id="range">
                <option value="select">-select-</option>
                <option value="bigFarmer">Big Farmer</option>
                <option value="mediumFarmer">Medium Farmer</option>
                <option value="smallFarmer">Small Farmer</option>
               </select>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-3 col-3  m-buttom">
                <p class="label">District</p>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-3 col-3 m-buttom">
               <select name="dist" id="dist">
                <option value="select">-select-</option>
                <?php 
                $sql="select * from dist";
                $res=mysqli_query($conn,$sql);
                while($data=mysqli_fetch_assoc($res))
                {
                    ?><option value="<?php echo $data["dist_id"];?>"><?php echo $data["dist_id"]."-".$data['Dist_Name'];?></option>
                    <?php
                }
                ?>  
               </select>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-3 col-2 m-buttom">
                <p class="label">block</p>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-3 col-4 m-buttom">
               <select name="block" id="block">
                <option value="select">-select-</option>
               </select>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-3 col-3  m-buttom">
                <p class="label">Panchayat</p>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-3 col-3 m-buttom">
               <select name="panchayat" id="panchayat">
                <option name="select">-select-</option>
               </select>
            </div>
            <div class="col-lg-2  m-buttom">
                <p class="label">Village</p>
            </div>
            <div class="col-lg-2  m-buttom">
             <input type="text" id="vill" class="" placeholder="" name="village">
            </div>
            <div class="col-lg-2 m-buttom">
                <p class="label">UIDAI No.</p>
            </div>
             <div class="col-lg-2 m-buttom">
             <input type="text" id="uidai" class="" placeholder="" name="uidai">
            </div>
            <div class="col-lg-2 col-md-2 col-sm-3 col-3 m-buttom">
                <p class="label">Select Bank</p>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-3 col-3 m-buttom">
             <select style="width: 100%;" name="bank" id="bank">
             <option value="select">-select-</option>
             <?php
             $res=mysqli_query($conn,"select * from bank");
             while($data=mysqli_fetch_assoc($res))
             {
                 ?><option value="<?php echo $data['bank_id']?>"><?php echo $data['bank_name']?></option>"<?php
             }
             ?>
             
             </select>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-3 col-3 m-buttom">
              <p class="label">IFSC code</p>
          </div>
           <div class="col-lg-2 col-md-2 col-sm-3 col-3 m-buttom">
           <input type="text" id="ifsc" class="" placeholder="" name="ifsc">
          </div>
          <div class="col-lg-2 m-buttom">
            <p class="label">A/C.</p>
        </div>
         <div class="col-lg-2 m-buttom">
         <input type="text" id="ac" class="" placeholder="" name="ac">
        </div>
            <div class="col-lg-2 m-buttom">
                <p class="label">Email id</p>
            </div>
            <div class="col-lg-2 m-buttom">
             <input type="email" id="email" name="email" class="" placeholder="">
            </div>
            <div class="col-lg-2  m-buttom">
                <p class="label">Mobile No.</p>
            </div>
            <div class="col-lg-2 m-buttom">
             <input type="text" id="mob" name="mob" class="" placeholder="">
             
             <p  id="alrt" style="color:red;display:none">Number already exist</p>
            </div>
            <div class="col-lg-2  m-buttom">
                <p class="label">Image(optional)</p>
            </div>
            <div class="col-lg-2 m-buttom">
             <input type="file" id="img" name="img">
            </div>
            <div class="col-lg-12 m-buttom">
              <center>
                <button type="reset" class="btn btn-danger">Clear</button>
                <button type="submit" class="btn btn-success" name="submit">Submit</button>
              </center>
             </div>
        </div>
        <legend align="center" style="background-color:rgb(93, 110, 198);color:aliceblue">हमारा द्वार भर गया सभी जानकारी सही है।</legend>
    </fieldset>
</form>

</section>
<!-- success popup -->
<div class="succ" id="succ" style="position:fixed;top:30%;left:33%;border:1px solid black;">

    <img src="../image/succ.png">
        <div style="color:green;text-align:center;font-size:30px;display:none;" id="success">Registration Succsess!</div>
        <a href="registration_get_details.php">click to download, Reg No. <?php echo $_GET['regi'];?></a>
</div>
<script>
  $(document).ready(function(){
    // dist dependent ajax
    $("#dist").on("change",function(){
      var dist_id = $(this).val();
      $.ajax({
        type:'POST',
        url :"action.php",
        data:'dist_id='+dist_id,
        success:function(result){
          $('#block').html(result);
          
        }
      });
    }); 
    $("#block").on("change",function(){
      var block_id = $(this).val();
      $.ajax({
        type:'POST',
        url :"action.php",
        data:'block_id='+block_id,
        success:function(result){
          $('#panchayat').html(result);
        }
      });
    }); 
  });
</script>
<script>

function formValidation()
{
let gaurdiun=document.getElementById('gaurdiun').value;
let fname=document.querySelector('#fname').value;
let lname=document.querySelector('#lname').value;
let dob=document.querySelector('#dob').value;
let block=document.querySelector('#block').value;
let sex=document.querySelector('#sex').value;
let category=document.querySelector('#category').value;
let range=document.querySelector('#range').value;
let uidai=document.querySelector('#uidai').value;
let dist=document.querySelector('#dist').value;
let panchayat=document.querySelector('#panchayat').value;
let mob=document.querySelector('#mob').value;
let ifsc=document.querySelector('#ifsc').value;
let ac=document.querySelector('#ac').value;
 if(gaurdiun=="" || fname=="" || lname=="" || dob=="" || block=="select" || sex=="select" || uidai=="" || dist=="select" || panchayat=="select" || mob=="" || ifsc=="" || range=="select") 
   {
    alert("all fields are mandatory");
    return false;
   }
   if(isNaN(mob) || mob.length<10 || mob.length>10 || mob.charAt(0)<6)
{
    alert("invalid mobile number");
return false;
}
if(isNaN(ac) || ac.length<4)
{
    alert("invalid account number");
return false;
}
if(isNaN(uidai) || uidai.length<12 || uidai.length>12)
{
    alert("invalid Adhaar Number");
return false;
}
   
}
</script>
<?php
if(isset($_GET['id']))
{
    if($_GET['id']=="success")
    { $r=$_GET['regi'];
        
        ?>
        <script>
            document.getElementById('succ').style.display="block";
            document.getElementById('success').style.display="block";
        </script>
        <?php
    }else if($_GET['id']=="fail")
    {
        ?>
        <script>
            document.getElementById('fail').style.display="block";
        </script>
        <?php
    }else{
        ?>
        <script>
            document.getElementById('success').style.display="none";
            document.getElementById('fail').style.display="none";
        </script>
        <?php
    }
}
?>
  <!-- <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script> -->
</body>
</html>