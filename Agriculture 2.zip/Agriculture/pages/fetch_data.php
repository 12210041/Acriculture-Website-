<?php
include '../includes/dbConnection.php';

if(isset($_GET['reg']))
            {
                $count=0;
             $sql3="select * from diesel where farmer_reg='$_GET[reg]';";
             $res3=mysqli_query($conn,$sql3);
             $data=mysqli_fetch_assoc($res3);
             $count =mysqli_num_rows($res3);
             if($count>0)

             {
                $app_id=$_GET['reg'].$data["d_id"];
                echo "<p style=color:blue;font-size:30px;> Already Applied ! Application No: $app_id</p>";
             }  else
             {

             
            $sql="select * from farmer_reg where concat('R',session,farmerid)='$_GET[reg]'";
            $res=mysqli_query($conn,$sql);
            $row=mysqli_fetch_assoc($res);
            if(mysqli_num_rows($res)>0)
            {
                $regi="R".$row['session'].$row['farmerid'];
                
            echo "
            <table width=100%>
            <tr style=border:none>
            <th style=border:none><img src='../image/up-logo@@@.png' width=100px height=100px></th>
            <td style=color:red;border:none></td>
            <th style=border:none><img src='$row[photo]' width=100px height=100px></th>
            <td style=border:none><img src='https://png.pngtree.com/png-clipart/20210808/original/pngtree-jai-jawan-kisan-t-shirt-design-hindi-local-lettering-with-texture-png-image_6615811.jpg' width=100px height=100px></td>
            </tr>
            <tr>
            <th >Registration Number</th>
            <td style=color:red>: $regi</td>
            <th>Registration Year</th>
            <td>: $row[session]</td>
            </tr>
            <tr>
            <th>First Name</th>
            <td>: $row[f_name]</td>
            <th>Last Name</th>
            <td>: $row[l_name]</td>
            </tr>
            <tr>
            <th>Farmer Type</th>
            <td>: $row[farmer_type]</td>
            <th>DOB</th>
            <td>: $row[dob]</td>
            </tr>
            <tr>
            <th>Sex</th>
            <td>: $row[sex]</td>
            <th>Category</th>
            <td>: $row[cotegory]</td>
            </tr>
            <tr>
            <th>District</th>
            <td>: $row[dist]</td>
            <th>Block</th>
            <td>: $row[block]</td>
            </tr>
            <tr>
            <th>Panchayat</th>
            <td>: Registration Number</td>
            <th>Village</th>
            <td>: Registration Number</td>
            </tr>
            <tr>
            <th>UIDAI No.</th>
            <td>: $row[uidai]</td>
            <th>Bank</th>
            <td>: $row[bank]</td>
            </tr>
            <tr>
            <th>IFSC Code.</th>
            <td>: $row[ifsc]</td>
            <th>AC Number</th>
            <td>: $row[ac]</td>
            </tr>
            <tr>
            <th>Email</th>
            <td>: $row[email]</td>
            <th>Mobile</th>
            <td>: $row[mob]</td>
            </tr>
            </table>




            <form method=POST action=dieselprocess.php?r='$regi'>
            <table width=100%>
            <tr>
            <th>Purchases Diesel Amount</th>
            <td>: <input type=text name=rs </td>
            <th>Diesel Invoice Number
            <p style=color:red>if more than 1 enter sepereted by comma(,)</p>
            </th>
            <td>: <input type=text name=invoice </td>
            </tr>
            <tr>
            <th>जमीन का खाता संख्या</th>
            <td>: <input type=text name=khata id=khata></td>
            <th>ज़मीन का सर्वेसंख्या
            <p style=color:red>if more than 1 enter sepereted by comma(,)</p>
            </th>
            <td>: <input type=text name=sarve </td>
            </tr>
            <tr>
            <th>कुल रकवा(in decimil)</th>
            <td>: <input type=text name=total </td>
            <td><button   type=reset style=width:100%;background-color:Red;color:white>Clear</button></td>
            <td><input  name=n id=n type=submit style=width:100%;background-color:green;color:white value=submit></td>
            </tr>
            </table>
            </form>
            ";
            }
        }
}

?>