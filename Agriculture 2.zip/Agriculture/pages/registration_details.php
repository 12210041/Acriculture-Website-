<style>
    .dow{
        padding:10px;
        background:green;
        border-radius:10px;
        color:white;
        justify-content:center;
        float:right;
    }
    .dow:hover{
        background:lightgreen;
        color:black;
        cursor:pointer;
    }
    
    </style>

<?php
include '../includes/dbConnection.php';
if(isset($_GET['reg']))
{
$sql="select * from farmer_reg where concat('R',session,farmerid)='$_GET[reg]' or mob='$_GET[reg]'";
$res=mysqli_query($conn,$sql);
$row=mysqli_fetch_assoc($res);
if(mysqli_num_rows($res)>0)
{
    $regi="R".$row['session'].$row['farmerid'];
echo "
<table width=100% border=1>
<tr style=border:none>
<th style=border:none><img src='../image/up-logo@@@.png' width=100px height=100px></th>
<td style=color:red;border:none></td>
<th style=border:none><img src='$row[photo]' width=100px height=100px></th>
<td style=border:none><img src='https://png.pngtree.com/png-clipart/20210808/original/pngtree-jai-jawan-kisan-t-shirt-design-hindi-local-lettering-with-texture-png-image_6615811.jpg' width=100px height=100px></td>
</tr>
<tr>
<th >Registration Number</th>
<td style=color:red>: $regi</td>
<th>Registration Year</th>
<td>: $row[session]</td>
</tr>
<tr>
<th>First Name</th>
<td>: $row[f_name]</td>
<th>Last Name</th>
<td>: $row[l_name]</td>
</tr>
<tr>
<th>Farmer Type</th>
<td>: $row[farmer_type]</td>
<th>DOB</th>
<td>: $row[dob]</td>
</tr>
<tr>
<th>Sex</th>
<td>: $row[sex]</td>
<th>Category</th>
<td>: $row[cotegory]</td>
</tr>
<tr>
<th>District</th>
<td>: $row[dist]</td>
<th>Block</th>
<td>: $row[block]</td>
</tr>
<tr>
<th>Panchayat</th>
<td>: Registration Number</td>
<th>Village</th>
<td>: Registration Number</td>
</tr>
<tr>
<th>UIDAI No.</th>
<td>: $row[uidai]</td>
<th>Bank</th>
<td>: $row[bank]</td>
</tr>
<tr>
<th>IFSC Code.</th>
<td>: $row[ifsc]</td>
<th>AC Number</th>
<td>: $row[ac]</td>
</tr>
<tr>
<th>Email</th>
<td>: $row[email]</td>
<th>Mobile</th>
<td>: $row[mob]</td>
</tr>
</table>
<a class='dow' id='download'>Download<i class='fa-solid fa-file-arrow-down'></i></a>
";
}
}

?>