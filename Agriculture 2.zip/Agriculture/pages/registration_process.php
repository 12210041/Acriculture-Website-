<?php
include '../includes/dbConnection.php';
$ftype=$_POST['farmer_type'];
$fname=$_POST['fname'];
$lname=$_POST['lname'];
$gaurd=$_POST['gaurdiun'];
$dob=$_POST['dob'];
$age=0;
$gender=$_POST['sex'];
$cat=$_POST['category'];
$range=$_POST['farmerRange'];
$dist=$_POST['dist'];
$block=$_POST['block'];
$panchayat=$_POST['panchayat'];
$vill=$_POST['village'];
$uidai=$_POST['uidai'];
$bank=$_POST['bank'];
$ifsc=$_POST['ifsc'];
$ac=$_POST['ac'];
$email=$_POST['email'];
$mob=$_POST['mob'];
$img="not";
include 'navbar_html';
if(isset($_FILES['img']))
        {
            $tmpfile=$_FILES['img']['tmp_name'];
            $filename=$_FILES['img']['name'];
            if(move_uploaded_file($tmpfile,"../upload_image/".$lname.$filename));
            $img="../upload_image/".$lname.$filename;
        }
        $count=0;
        $sql3="select mob from farmer_reg where mob='$_POST[mob]'";
        $res=mysqli_query($conn,$sql3);
        $count=mysqli_num_rows($res);
        if($count>0)
        {
            ?>
            <script>
                window.location="registration.php"; 
                document.querySelector('#alrt').style.display="block";
            </script>
            <?php
        } else
        {

        
$sql="insert into farmer_reg(farmer_type,f_name,l_name,guardian,dob,sex,cotegory,farmer_range,dist,block,village,uidai,ifsc,ac,email,mob,photo,panchayat,session,bank) values('$ftype','$fname','$lname','$gaurd','$dob','$gender','$cat','$range',$dist,$block,'$vill','$uidai','$ifsc','$ac','$email','$mob','$img',$panchayat,'2022-23',$bank);";
if(!mysqli_query($conn,$sql))
{
//    $error=mysqli_error($conn);
//    print("Error Occurred: ".$error);
header("location:registration.php?id=fail");
}else
{
    $regi="R2022-13".mysqli_insert_id($conn);
    header("location:registration.php?id=success&regi='$regi'");
}
        }
?>

