
<?php
include '../includes/dbConnection.php';
$rr=$_GET['r'];
{
        $sql="insert into diesel(rs,invoice,khata,sarve,rakwa,farmer_reg) values($_POST[rs],'$_POST[invoice]','$_POST[khata]','$_POST[sarve]',$_POST[total],$rr);";
        if(!mysqli_query($conn,$sql))
        {
        ?>
        <script>alert("Something went wrong!");
        // window.location="diesel.php";
        </script>

        <?php
        echo mysqli_error($conn);
        }else
        {
            ?>
        <script>alert("Your Application has been submitted successfully");
        window.location="../index.php";
        </script>

        <?php

        }
    }
?>