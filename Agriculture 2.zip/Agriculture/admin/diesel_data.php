<style>
    table{
        
        collapse:collapse;
    }
    td{
        border:1px solid black;
    }
    tr:first-child{
        background:green;
        color:white;
    }
    
    </style>
<?php
include '../includes/dbConnection.php';
echo "<table width=100%>
<tr>
    <td>Registartion Number</td>
    <td>Application Number</td>
    <td>Khata No.</td>
    <td>Sarve No.</td>
    <td>Diesel Invoice No.</td>
    <td>Purchase Amount</td>
    <td>Apply Date</td>
    <td>Application Status</td>
    <td>Updation</td>
    <tr>
";
$sql="select * from diesel";
$query=mysqli_query($conn,$sql);
while($data=mysqli_fetch_assoc($query))
{
    echo "
    <tr>
    <td>$data[farmer_reg]</td>
    <td>$data[farmer_reg]$data[d_id]</td>
    <td>$data[khata]</td>
    <td>$data[sarve]</td>
    <td>$data[invoice]</td>
    <td>$data[rs]</td>
    <td>$data[applydate]</td>
    <td>$data[status]</td>
    <td>
        <form method='POST' action='updatestatusd.php?id=$data[d_id]'>
        <select name=upd >
        <option value='Approved'>Approved</option>
        <option value='Rejected'>Reject</option>
        <option value='Processing'>Process</option>
        </select>
        <input type=submit value=Update style='background-color:green;color:yellow;'>
        </form>
    </td>
    <tr>
   ";
}
echo "</table>";
?>