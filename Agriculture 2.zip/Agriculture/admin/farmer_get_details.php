<style>
    table{
        border:1px solid green;
        border-collapse: collapse;
    }
    th{
        background:lightblue;
        color:red;
        font-weight:600;
        border:1px solid green;
        text-align:center;
    }
    tr{
        
       
    }
    td{
        text-align:center;
    }
    tr:hover{
        background:skyblue;
        color:white;
        font-weight:600;
    }
    /* tr:nth-child(odd) {
        
        } */
        ::-webkit-scrollbar {
  width: 10px;
}

/* Track */
::-webkit-scrollbar-track {
  background: #f1f1f1;
}

/* Handle */
::-webkit-scrollbar-thumb {
  background: #888;
}

/* Handle on hover */
::-webkit-scrollbar-thumb:hover {
  background: #555;
}
table img:hover{
   transform:translateX(30%) scale(2);
   transition:.5s;
   
   border-radius:50%;
   
}
    </style>
<?php
include '../includes/dbConnection.php';
$sql="select * from farmer_reg";
$res=mysqli_query($conn,$sql);
echo "
<label>Search By Registration Number</label>
<input type='search' id='search' style=''>
<a href><i class='fa fa-magnifying-glass'></i></a>
<table width=200%>
<tr>
<th>
photo
</th>
<th>
Registration Number
</th>
<th>
Name
</th><th>
DOB
</th><th>
Category
</th><th>
Farmer Range
</th><th>
Dist
</th><th>
Block
</th><th>
Panchayat
</th><th>
Village
</th><th>
uidai
</th><th>
Bank
</th><th>
Ifsc
</th><th>
Ac
</th><th>
Email
</th><th>
Mobile
</th><th>
Farmer-Type
</th><th>
Registration Date
</th><th>
Delete
</th><th>
update
</th>
</tr>
";

while($row=mysqli_fetch_assoc($res))

{
    $sqldist="select Dist_Name from dist where dist_id=$row[dist]";
    $resdist=mysqli_query($conn,$sqldist);
    $rowdist=mysqli_fetch_array($resdist);


    $sqlblock="select block_name from block where block_id=$row[block]";
    $resblock=mysqli_query($conn,$sqlblock);
    $rowblock=mysqli_fetch_array($resblock);

    $sqlp="select panchayat from panchayat where p_id=$row[panchayat]";
    $resp=mysqli_query($conn,$sqlp);
    $rowp=mysqli_fetch_array($resp);

    $sqlb="select bank_name from bank where bank_id=$row[bank]";
    $resb=mysqli_query($conn,$sqlb);
    $rowb=mysqli_fetch_array($resb);


    echo "<tr>
    <td><img src='$row[photo]' width='100px'></td>
    <td>R$row[session]$row[farmerid]</td>
    <td>$row[f_name] $row[l_name]</td>
    
    <td>$row[dob]</td>
    <td>$row[cotegory]</td>
    <td>$row[farmer_range]</td>
    <td>$rowdist[Dist_Name]</td>
    <td>$rowblock[block_name]</td>
    <td>$rowp[panchayat]</td>
    <td>$row[village]</td>
    <td>$row[uidai]</td>
    <td>$rowb[bank_name]</td>
    <td>$row[ifsc]</td>
    <td>$row[ac]</td>
    <td>$row[email]</td>
    <td>$row[mob]</td>
    <td>$row[farmer_type]</td>
    <td>$row[reg_date]</td>
    <td><a href><i class='fa-sharp fa-solid fa-trash'></i></a></td>
    <td><a href><i class='fa fa-pen-to-square'></i></a></td>
    </tr>";
}
echo "

</table>

</nav>
";
?>