<?php
include 'verifylogin.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Official Login</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="../JS/jquery.js"></script>
    <style>
        .head{
            display:flex;
            justify-content:left;
        }
        .head img{
            width:5%;
            padding:10px 5px 10px 20%;
            height:100px;
        }
        .nav{
            background-color:rgb(138,206,128);
        }
        ul{
            display:flex;
            justify-content:space-around;
            width:50%;
            list-style:none;
        }
        li{
            padding:20px;
        }
        li a{
           text-decoration:none; 
           font-size:25px;
       
           
        }
       
        li a:hover{
            
            border-bottom:2px solid red;
            color:white;
            cursor:pointer;
        }
        #contain{
            overflow:scroll;
            width:100%;
       
            box-shadow:6px 7px 10px black;
        }
        .container{
        display:grid;
        grid-template-columns:auto;
        gap:5%;
        width:80%;
        margin-left:10%;
    }
    .item{
        background:pink;
        box-shadow:7px 7px 10px lightblue;
        font-size:30px;
        text-align:center;
    }
    a{
        text-decoration:none;
    }
    .item p:first-child{
        color:green;
    }
    .item:hover{
        cursor:pointer;
    }
    span{
        color:red;
    }
    
      
        </style>
        
</head>
<body>
    <header class="head">
       
        <img src="../image/up-logo@@@.png">
    
    <div style="display:block;padding-top:15px;line-height: 80%">
        <p style="font-size:30px;font-weight:600;"> DIRECT BENEFIT TRANSFER (DBT)</p>
        <p style="font-size:20px;">DEPARTMENT OF AGRICULTURE, BIHAR</p>
    </div>
    </header>
    <nav class="nav">
        <ul>
            <li><a  id="scheme">Scheme</a></li>
            <li><a  id="f_details">Farmer Details</a></li>
            <li><a href="logout.php">Farmer Portal</a></li>
            <li><a id="login" href="logout.php">Logout</a></li>
    </ul>
    </nav>
  <section id="contain">
</section>
    <div class=container>
            <div class='item' id='dieseld'>
            </div>
        </div>
    <section id="diseldetails">
       
    </section>
    <script>
        $(document).ready(function(){
            
            $.ajax({
                url:'scheme.php',
                success:function(data)
                {
                    $('#dieseld').html(data);
                }
            });


           $('#scheme').click(function(){
            $('#contain').css({"display":"none"});
            $('.container').css({"display":"block"});
            $('#diseldetails').css({"display":"none"});
            $.ajax({
                url:'scheme.php',
                success:function(data)
                {
                    $('#dieseld').html(data);
                }
            });
           });
           $('#f_details').click(function(){
            $('#contain').css({"display":"block"});
            $('.container').css({"display":"none"});
            $('#diseldetails').css({"display":"none"});
            $.ajax({
                url:'farmer_get_details.php',
                success:function(data){
                    $('#contain').html(data);
                }
            });
           });
         $('#dieseld').click(function(){
            $('#diseldetails').css({"display":"block"});
           $.ajax({
                url:'diesel_data.php',
                success:function(data){
                    $('#diseldetails').html(data);
                }
           });
         });
        }); 
        
   </script>
</body>
</html>