<?php include 'login_process.php';
        include '../includes/dbConnection.php';
session_start();
if(isset($_SESSION['username']))
{
    header("location:index.php");
}

if(isset($_POST['log']))
{
  $sql="select * from admin where username='$_POST[user]' and pass='$_POST[pass]'";
  $res=mysqli_query($conn,$sql);
  if(mysqli_num_rows($res)>0)
  {
    header("location:index.php");
    $_SESSION['username']=$_POST['user'];
  }
  else
  {
    echo "<script> alert('Invalid user and password');</script>";
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
          .alert{
            position:fixed;
            width:30%;
            top:30%;
            left:35%;
            background:lightgreen;
            display:none;
            border-radius:10px;
            box-shadow:10px 5px 10px black;
            text-align:center;
            font-size:30px;

        }
        #ok{
            background:green;
            color:white;
            padding:1%;
            
        }
        #ok:hover{
            box-shadow:5px 5px 8px gray;
            cursor: pointer;
        }
        </style>
</head>
<body>
    <div class="alert">
        <p>Log Out Successfully</p>
        <a id="ok" href="login.php">Ok</a>
    </div>
    <?php
    if($_GET['mes']=="logout")
    {
       ?>
        <script>
        document.querySelector('.alert').style.display='block';
        </script>
        <?php
    }
    ?>
</body>
</html>