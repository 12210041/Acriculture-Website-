<?php
include '../includes/dbConnection.php';
if(isset($_GET['id']))
{
    $x="UPDATE diesel SET status='$_POST[upd]' where d_id=$_GET[id]";
    if(mysqli_query($conn,$x))
    {
        header("location:index.php");
    }
    
}

?>