<style>
    .grid{
        display:grid;
        grid-template-columns:40% 40%;
        height:400px;
        margin-left:10%;
        margin-top:100px;
        gap:5%;
    }
    .grid-item1{
        background:gray;
        border-radius:20px;
    }
    input{
        display:block;
        width:80%;
        font-size:30px;
        padding:5px;
        margin:2% 0% 5% 10%;
        border-radius:20px;
    }
    label{
        display:block;
        width:80%;
        font-size:30px;
        padding:3px;
        margin:0% 0% 0% 10%;
    }
    .item2{
        padding-top:30%;
        font-size:40px;
        font-weight:600;
        color:white;
        text-shadow:2px 4px 5px green;
        text-align:center;
    }
    </style>
<?php

echo "
<div class=grid>
    <div class='grid-item1 item2'>
    DBT | PM-KISAN SCHEME (Official Login)
    </div>
    <div class=grid-item1>
    <center style='font-size:30px;color:white;font-weight:600'>Official Login</center>
    <form method='POST' >
    <label>User Id</label>
    <input type=text placeholde='User id' name='user'>
    <label>Password</label>
    <input type=password  name='pass'>
    <input type='submit' id='log' name='log' value='login'>
    </form>
    <a href='../'>back to Farmer Portal</p>
    </div>
</div>
";
?>