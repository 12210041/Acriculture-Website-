<?php
$conn=mysqli_connect("localhost","root","","Agriculture");
if(!$conn)
{
    die("Connectin not successfully");
}

?>
