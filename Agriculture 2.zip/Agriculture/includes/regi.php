<?php 
include '/Agriculture/includes/dbConnection.php';

?>